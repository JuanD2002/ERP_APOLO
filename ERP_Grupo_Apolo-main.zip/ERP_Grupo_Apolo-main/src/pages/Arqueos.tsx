import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Calculator, DollarSign, Coins, TrendingUp, AlertTriangle, ChevronLeft, ChevronRight } from "lucide-react";
import { format, parseISO, subDays, addDays } from "date-fns";
import { es } from "date-fns/locale";
import { useCompany } from "@/hooks/useCompany";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend,
  LineChart, Line,
} from "recharts";

const fmtCOP = (n: number) =>
  new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 }).format(n || 0);

const Arqueos = () => {
  const { activeCompanyId, activeCompany, activeBranchId, activeBranch } = useCompany();
  const [date, setDate] = useState<string>(format(new Date(), "yyyy-MM-dd"));
  const [cash, setCash] = useState<any | null>(null);
  const [products, setProducts] = useState<any[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => { if (activeCompanyId) void load(); }, [activeCompanyId, activeBranchId, date]);

  const load = async () => {
    if (!activeCompanyId) return;
    setLoading(true);

    let cashQ = supabase.from("daily_cash_close").select("*")
      .eq("company_id", activeCompanyId).eq("date", date);
    if (activeBranchId) cashQ = cashQ.eq("branch_id", activeBranchId);

    let prodQ = supabase.from("daily_product_sales").select("*")
      .eq("company_id", activeCompanyId).eq("date", date);
    if (activeBranchId) prodQ = prodQ.eq("branch_id", activeBranchId);

    const since = format(subDays(parseISO(date), 29), "yyyy-MM-dd");
    let histQ = supabase.from("daily_cash_close").select("date, total_venta, total_efectivo, cuadre")
      .eq("company_id", activeCompanyId).gte("date", since).lte("date", date).order("date");
    if (activeBranchId) histQ = histQ.eq("branch_id", activeBranchId);

    const [{ data: cashRows }, { data: prodRows }, { data: histRows }] = await Promise.all([cashQ, prodQ, histQ]);

    const agg = (cashRows ?? []).reduce((acc: any, r: any) => ({
      base_inicial: acc.base_inicial + Number(r.base_inicial || 0),
      total_efectivo: acc.total_efectivo + Number(r.total_efectivo || 0),
      total_venta: acc.total_venta + Number(r.total_venta || 0),
      cuadre: acc.cuadre + Number(r.cuadre || 0),
      cash_breakdown: r.cash_breakdown ?? acc.cash_breakdown,
    }), { base_inicial: 0, total_efectivo: 0, total_venta: 0, cuadre: 0, cash_breakdown: null });

    setCash(cashRows && cashRows.length ? agg : null);
    setProducts(prodRows ?? []);

    // Aggregate history by date (sum across branches if any)
    const byDate = new Map<string, any>();
    (histRows ?? []).forEach((r: any) => {
      const cur = byDate.get(r.date) ?? { date: r.date, total_venta: 0, total_efectivo: 0, cuadre: 0 };
      cur.total_venta += Number(r.total_venta || 0);
      cur.total_efectivo += Number(r.total_efectivo || 0);
      cur.cuadre += Number(r.cuadre || 0);
      byDate.set(r.date, cur);
    });
    setHistory([...byDate.values()].map((r) => {
      const d = r.date ? parseISO(r.date) : null;
      return {
        ...r,
        label: d && !isNaN(d.getTime()) ? format(d, "dd MMM", { locale: es }) : String(r.date ?? ""),
      };
    }));


    setLoading(false);
  };

  const totalUnits = useMemo(() => products.reduce((s, p) => s + Number(p.venta_unidades || 0), 0), [products]);
  const productSalesTotal = useMemo(() => products.reduce((s, p) => s + Number(p.total_venta || 0), 0), [products]);

  const shift = (n: number) => setDate(format(addDays(parseISO(date), n), "yyyy-MM-dd"));

  return (
    <div>
      <PageHeader
        title="Arqueos diarios"
        description={
          activeCompany
            ? `${activeCompany.name}${activeBranch ? ` · ${activeBranch.name}` : " · Todas las sedes"}`
            : "Cierres de caja y ventas por producto"
        }
        icon={<Calculator className="h-5 w-5" />}
      />

      <div className="flex flex-wrap items-center gap-2 mb-6">
        <Button size="icon" variant="outline" onClick={() => shift(-1)}><ChevronLeft className="h-4 w-4" /></Button>
        <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-44" />
        <Button size="icon" variant="outline" onClick={() => shift(1)}><ChevronRight className="h-4 w-4" /></Button>
        <Button size="sm" variant="ghost" onClick={() => setDate(format(new Date(), "yyyy-MM-dd"))}>Hoy</Button>
        {loading && <span className="text-xs text-muted-foreground">Cargando…</span>}
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card><CardContent className="p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-sm"><DollarSign className="h-4 w-4" /> Total venta</div>
          <div className="text-2xl font-bold mt-1">{fmtCOP(cash?.total_venta ?? productSalesTotal)}</div>
          <span className="text-xs text-muted-foreground">{totalUnits.toFixed(0)} unidades</span>
        </CardContent></Card>
        <Card><CardContent className="p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-sm"><Coins className="h-4 w-4" /> Efectivo contado</div>
          <div className="text-2xl font-bold mt-1">{fmtCOP(cash?.total_efectivo ?? 0)}</div>
          <span className="text-xs text-muted-foreground">Base: {fmtCOP(cash?.base_inicial ?? 0)}</span>
        </CardContent></Card>
        <Card><CardContent className="p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-sm"><TrendingUp className="h-4 w-4" /> Cuadre</div>
          <div className={`text-2xl font-bold mt-1 ${Number(cash?.cuadre ?? 0) < 0 ? "text-destructive" : "text-success"}`}>
            {fmtCOP(cash?.cuadre ?? 0)}
          </div>
          <span className="text-xs text-muted-foreground">Efectivo − (Base + Venta)</span>
        </CardContent></Card>
        <Card><CardContent className="p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-sm"><AlertTriangle className="h-4 w-4" /> Productos</div>
          <div className="text-2xl font-bold mt-1">{products.length}</div>
          <span className="text-xs text-muted-foreground">registrados ese día</span>
        </CardContent></Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Ventas — últimos 30 días</CardTitle>
            <CardDescription>Tendencia de cierre por día</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={history}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="label" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickFormatter={(v) => `${(v/1000).toFixed(0)}k`} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} formatter={(v: number) => fmtCOP(v)} />
                <Legend />
                <Line type="monotone" dataKey="total_venta" name="Venta" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="total_efectivo" name="Efectivo" stroke="hsl(var(--accent))" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Productos vendidos ({format(parseISO(date), "dd MMM yyyy", { locale: es })})</CardTitle>
            <CardDescription>Top por unidades</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={[...products].sort((a, b) => Number(b.venta_unidades) - Number(a.venta_unidades)).slice(0, 8)}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="product_name" stroke="hsl(var(--muted-foreground))" fontSize={10} interval={0} angle={-20} textAnchor="end" height={60} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} allowDecimals={false} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                <Bar dataKey="venta_unidades" name="Unidades" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base">Inventario y ventas por producto</CardTitle>
          <CardDescription>Datos del cierre del día seleccionado</CardDescription>
        </CardHeader>
        <CardContent>
          {products.length === 0 ? (
            <p className="text-sm text-muted-foreground">Sin datos para esta fecha. Sincroniza la hoja en Administración → Google.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Producto</TableHead>
                    <TableHead className="text-right">Inv. inicial</TableHead>
                    <TableHead className="text-right">Entradas</TableHead>
                    <TableHead className="text-right">Inv. final</TableHead>
                    <TableHead className="text-right">Vendidos</TableHead>
                    <TableHead className="text-right">Precio</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {products.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell className="font-medium">{p.product_name}</TableCell>
                      <TableCell className="text-right">{Number(p.inv_inicial).toFixed(0)}</TableCell>
                      <TableCell className="text-right">{Number(p.entradas).toFixed(0)}</TableCell>
                      <TableCell className="text-right">{Number(p.inv_final).toFixed(0)}</TableCell>
                      <TableCell className="text-right font-semibold">{Number(p.venta_unidades).toFixed(0)}</TableCell>
                      <TableCell className="text-right">{fmtCOP(Number(p.precio))}</TableCell>
                      <TableCell className="text-right font-semibold">{fmtCOP(Number(p.total_venta))}</TableCell>
                    </TableRow>
                  ))}
                  <TableRow className="bg-muted/30">
                    <TableCell className="font-bold">Total</TableCell>
                    <TableCell />
                    <TableCell />
                    <TableCell />
                    <TableCell className="text-right font-bold">{totalUnits.toFixed(0)}</TableCell>
                    <TableCell />
                    <TableCell className="text-right font-bold">{fmtCOP(productSalesTotal)}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {cash?.cash_breakdown && Array.isArray(cash.cash_breakdown) && cash.cash_breakdown.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Conteo de efectivo</CardTitle>
            <CardDescription>Desglose por denominación</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Denominación</TableHead>
                    <TableHead className="text-right">Cantidad</TableHead>
                    <TableHead className="text-right">Subtotal</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {cash.cash_breakdown.map((c: any, i: number) => (
                    <TableRow key={i}>
                      <TableCell>{c.denomination ?? c.label ?? "—"}</TableCell>
                      <TableCell className="text-right">{Number(c.quantity ?? c.qty ?? 0).toFixed(0)}</TableCell>
                      <TableCell className="text-right">{fmtCOP(Number(c.subtotal ?? 0))}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default Arqueos;
