import { useEffect, useMemo, useState } from "react";
import { Navigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { BarChart3, CalendarIcon, Download, FileSpreadsheet, FileText } from "lucide-react";
import { format, startOfWeek, startOfMonth, startOfYear, endOfDay } from "date-fns";
import { es } from "date-fns/locale";
import { useCompany } from "@/hooks/useCompany";
import { cn } from "@/lib/utils";
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid } from "recharts";
import { toast } from "sonner";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";

type GroupBy = "company" | "branch";
type Preset = "today" | "week" | "month" | "year" | "custom";

interface Company { id: string; name: string }
interface Branch { id: string; name: string; company_id: string }

const fmtCOP = (n: number) =>
  new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 }).format(n);

const toISO = (d: Date) => format(d, "yyyy-MM-dd");

export default function Reportes() {
  const { isSuperAdmin, companies: userCompanies, loading } = useCompany();
  const [companies, setCompanies] = useState<Company[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [selectedCompanies, setSelectedCompanies] = useState<string[]>([]);
  const [groupBy, setGroupBy] = useState<GroupBy>("company");
  const [preset, setPreset] = useState<Preset>("month");
  const [from, setFrom] = useState<Date>(startOfMonth(new Date()));
  const [to, setTo] = useState<Date>(endOfDay(new Date()));

  const [cashRows, setCashRows] = useState<any[]>([]);
  const [productRows, setProductRows] = useState<any[]>([]);
  const [stockRows, setStockRows] = useState<any[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [attendance, setAttendance] = useState<any[]>([]);

  // Init company list
  useEffect(() => {
    if (loading) return;
    const list = (userCompanies ?? []).map((c: any) => ({ id: c.id, name: c.name }));
    setCompanies(list);
    setSelectedCompanies(list.map((c) => c.id));
  }, [userCompanies, loading]);

  // Load branches
  useEffect(() => {
    if (selectedCompanies.length === 0) { setBranches([]); return; }
    (async () => {
      const { data } = await supabase.from("branches").select("id,name,company_id").in("company_id", selectedCompanies);
      setBranches((data ?? []) as Branch[]);
    })();
  }, [selectedCompanies]);

  // Apply preset
  const applyPreset = (p: Preset) => {
    setPreset(p);
    const now = new Date();
    if (p === "today") { setFrom(now); setTo(now); }
    else if (p === "week") { setFrom(startOfWeek(now, { weekStartsOn: 1 })); setTo(now); }
    else if (p === "month") { setFrom(startOfMonth(now)); setTo(now); }
    else if (p === "year") { setFrom(startOfYear(now)); setTo(now); }
  };

  // Load data
  useEffect(() => {
    if (selectedCompanies.length === 0) {
      setCashRows([]); setProductRows([]); setStockRows([]); setEmployees([]); setAttendance([]);
      return;
    }
    void loadAll();
  }, [selectedCompanies, from, to]);

  const loadAll = async () => {
    const fromISO = toISO(from);
    const toISOd = toISO(to);

    const [cash, prods, stock, emps] = await Promise.all([
      supabase.from("daily_cash_close").select("*").in("company_id", selectedCompanies)
        .gte("date", fromISO).lte("date", toISOd),
      supabase.from("daily_product_sales").select("*").in("company_id", selectedCompanies)
        .gte("date", fromISO).lte("date", toISOd),
      supabase.from("products").select("id,name,stock,min_stock,cost,price,company_id,branch_id")
        .in("company_id", selectedCompanies),
      supabase.from("employees").select("id,full_name,is_active,company_id,branch_id")
        .in("company_id", selectedCompanies),
    ]);
    setCashRows(cash.data ?? []);
    setProductRows(prods.data ?? []);
    setStockRows(stock.data ?? []);
    setEmployees(emps.data ?? []);

    const empIds = (emps.data ?? []).map((e: any) => e.id);
    if (empIds.length) {
      const { data: att } = await supabase.from("attendance").select("id,employee_id,check_in,check_out")
        .in("employee_id", empIds)
        .gte("check_in", from.toISOString())
        .lte("check_in", endOfDay(to).toISOString());
      setAttendance(att ?? []);
    } else {
      setAttendance([]);
    }
  };

  // ---------- Grouping helpers ----------
  const companyName = (id: string) => companies.find((c) => c.id === id)?.name ?? "—";
  const branchName = (id: string | null) => id ? (branches.find((b) => b.id === id)?.name ?? "—") : "Sin sede";

  const groupKey = (row: { company_id: string; branch_id: string | null }) =>
    groupBy === "company" ? row.company_id : `${row.company_id}::${row.branch_id ?? "none"}`;
  const groupLabel = (key: string) => {
    if (groupBy === "company") return companyName(key);
    const [cid, bid] = key.split("::");
    return `${companyName(cid)} · ${branchName(bid === "none" ? null : bid)}`;
  };

  // ---------- Ventas (cash) ----------
  const ventasData = useMemo(() => {
    const map = new Map<string, { totalVenta: number; baseInicial: number; dias: number }>();
    for (const r of cashRows) {
      const k = groupKey(r);
      const cur = map.get(k) ?? { totalVenta: 0, baseInicial: 0, dias: 0 };
      cur.totalVenta += Number(r.total_venta ?? 0);
      cur.baseInicial += Number(r.base_inicial ?? 0);
      cur.dias += 1;
      map.set(k, cur);
    }
    return Array.from(map.entries()).map(([k, v]) => ({
      key: k, label: groupLabel(k),
      totalVenta: v.totalVenta, baseInicial: v.baseInicial, dias: v.dias,
      promedio: v.dias ? Math.round(v.totalVenta / v.dias) : 0,
    })).sort((a, b) => b.totalVenta - a.totalVenta);
  }, [cashRows, groupBy, companies, branches]);

  // ---------- Productos ----------
  const productosData = useMemo(() => {
    const map = new Map<string, { unidades: number; total: number }>();
    for (const r of productRows) {
      const k = r.product_name as string;
      const cur = map.get(k) ?? { unidades: 0, total: 0 };
      cur.unidades += Number(r.venta_unidades ?? 0);
      cur.total += Number(r.total_venta ?? 0);
      map.set(k, cur);
    }
    return Array.from(map.entries())
      .map(([name, v]) => ({ name, unidades: v.unidades, total: v.total }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 15);
  }, [productRows]);

  // ---------- Inventario ----------
  const inventarioData = useMemo(() => {
    const map = new Map<string, { productos: number; valor: number; bajos: number }>();
    for (const p of stockRows) {
      const k = groupKey(p);
      const cur = map.get(k) ?? { productos: 0, valor: 0, bajos: 0 };
      cur.productos += 1;
      cur.valor += Number(p.stock ?? 0) * Number(p.cost ?? 0);
      if (Number(p.stock ?? 0) <= Number(p.min_stock ?? 0)) cur.bajos += 1;
      map.set(k, cur);
    }
    return Array.from(map.entries()).map(([k, v]) => ({
      key: k, label: groupLabel(k), ...v,
    })).sort((a, b) => b.valor - a.valor);
  }, [stockRows, groupBy, companies, branches]);

  // ---------- Empleados ----------
  const empleadosData = useMemo(() => {
    const empIndex = new Map(employees.map((e: any) => [e.id, e]));
    const map = new Map<string, { activos: number; total: number; turnos: number; horas: number }>();
    for (const e of employees) {
      const k = groupKey(e);
      const cur = map.get(k) ?? { activos: 0, total: 0, turnos: 0, horas: 0 };
      cur.total += 1;
      if (e.is_active) cur.activos += 1;
      map.set(k, cur);
    }
    for (const a of attendance) {
      const emp = empIndex.get(a.employee_id);
      if (!emp) continue;
      const k = groupKey(emp);
      const cur = map.get(k) ?? { activos: 0, total: 0, turnos: 0, horas: 0 };
      cur.turnos += 1;
      if (a.check_out) {
        const ms = new Date(a.check_out).getTime() - new Date(a.check_in).getTime();
        cur.horas += Math.max(0, ms / 3_600_000);
      }
      map.set(k, cur);
    }
    return Array.from(map.entries()).map(([k, v]) => ({
      key: k, label: groupLabel(k), ...v, horas: Math.round(v.horas * 10) / 10,
    })).sort((a, b) => b.activos - a.activos);
  }, [employees, attendance, groupBy, companies, branches]);

  // ---------- Exports ----------
  const exportXLSX = () => {
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(ventasData.map((r) => ({
      Grupo: r.label, "Total venta": r.totalVenta, "Base inicial": r.baseInicial, Días: r.dias, "Promedio diario": r.promedio,
    }))), "Ventas");
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(productosData.map((r) => ({
      Producto: r.name, Unidades: r.unidades, Total: r.total,
    }))), "Productos");
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(inventarioData.map((r) => ({
      Grupo: r.label, Productos: r.productos, "Valor inventario": r.valor, "Stock bajo": r.bajos,
    }))), "Inventario");
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(empleadosData.map((r) => ({
      Grupo: r.label, Activos: r.activos, Total: r.total, Turnos: r.turnos, Horas: r.horas,
    }))), "Empleados");
    XLSX.writeFile(wb, `reporte_${toISO(from)}_${toISO(to)}.xlsx`);
    toast.success("Excel descargado");
  };

  const exportCSV = () => {
    const lines: string[] = [];
    const push = (title: string, headers: string[], rows: (string | number)[][]) => {
      lines.push(title);
      lines.push(headers.join(","));
      for (const r of rows) lines.push(r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(","));
      lines.push("");
    };
    push("VENTAS", ["Grupo", "Total venta", "Base inicial", "Dias", "Promedio diario"],
      ventasData.map((r) => [r.label, r.totalVenta, r.baseInicial, r.dias, r.promedio]));
    push("PRODUCTOS", ["Producto", "Unidades", "Total"],
      productosData.map((r) => [r.name, r.unidades, r.total]));
    push("INVENTARIO", ["Grupo", "Productos", "Valor", "Stock bajo"],
      inventarioData.map((r) => [r.label, r.productos, r.valor, r.bajos]));
    push("EMPLEADOS", ["Grupo", "Activos", "Total", "Turnos", "Horas"],
      empleadosData.map((r) => [r.label, r.activos, r.total, r.turnos, r.horas]));
    const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `reporte_${toISO(from)}_${toISO(to)}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV descargado");
  };

  const exportPDF = () => {
    const doc = new jsPDF({ orientation: "landscape" });
    doc.setFontSize(16);
    doc.text("Informe comparativo", 14, 16);
    doc.setFontSize(10);
    doc.text(`Período: ${format(from, "dd MMM yyyy", { locale: es })} → ${format(to, "dd MMM yyyy", { locale: es })}`, 14, 22);
    doc.text(`Agrupado por: ${groupBy === "company" ? "Empresa" : "Sede"}`, 14, 27);

    autoTable(doc, {
      startY: 32, head: [["Ventas — Grupo", "Total venta", "Base inicial", "Días", "Prom. diario"]],
      body: ventasData.map((r) => [r.label, fmtCOP(r.totalVenta), fmtCOP(r.baseInicial), String(r.dias), fmtCOP(r.promedio)]),
      styles: { fontSize: 9 }, headStyles: { fillColor: [40, 40, 40] },
    });
    autoTable(doc, {
      head: [["Top productos", "Unidades", "Total"]],
      body: productosData.map((r) => [r.name, r.unidades.toLocaleString("es-CO"), fmtCOP(r.total)]),
      styles: { fontSize: 9 }, headStyles: { fillColor: [40, 40, 40] },
    });
    autoTable(doc, {
      head: [["Inventario — Grupo", "Productos", "Valor", "Stock bajo"]],
      body: inventarioData.map((r) => [r.label, String(r.productos), fmtCOP(r.valor), String(r.bajos)]),
      styles: { fontSize: 9 }, headStyles: { fillColor: [40, 40, 40] },
    });
    autoTable(doc, {
      head: [["Empleados — Grupo", "Activos", "Total", "Turnos", "Horas"]],
      body: empleadosData.map((r) => [r.label, String(r.activos), String(r.total), String(r.turnos), String(r.horas)]),
      styles: { fontSize: 9 }, headStyles: { fillColor: [40, 40, 40] },
    });

    doc.save(`reporte_${toISO(from)}_${toISO(to)}.pdf`);
    toast.success("PDF descargado");
  };

  if (loading) return null;
  if (!isSuperAdmin) return <Navigate to="/dashboard" replace />;

  const toggleCompany = (id: string) => {
    setSelectedCompanies((cur) => cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]);
  };

  return (
    <div>
      <PageHeader
        title="Reportes y comparativos"
        description="Compara el desempeño entre empresas y sedes, y exporta informes"
        icon={<BarChart3 className="h-5 w-5" />}
        action={
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={exportCSV}><Download className="h-4 w-4 mr-2" />CSV</Button>
            <Button variant="outline" size="sm" onClick={exportXLSX}><FileSpreadsheet className="h-4 w-4 mr-2" />Excel</Button>
            <Button size="sm" onClick={exportPDF}><FileText className="h-4 w-4 mr-2" />PDF</Button>
          </div>
        }
      />

      {/* Filters */}
      <Card className="mb-4">
        <CardContent className="p-4 grid gap-4 md:grid-cols-4">
          <div>
            <Label className="text-xs">Período</Label>
            <Select value={preset} onValueChange={(v) => applyPreset(v as Preset)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Hoy</SelectItem>
                <SelectItem value="week">Esta semana</SelectItem>
                <SelectItem value="month">Este mes</SelectItem>
                <SelectItem value="year">Este año</SelectItem>
                <SelectItem value="custom">Personalizado</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Desde</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className={cn("w-full justify-start text-left font-normal")}>
                  <CalendarIcon className="h-4 w-4 mr-2" />
                  {format(from, "dd MMM yyyy", { locale: es })}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={from} onSelect={(d) => { if (d) { setFrom(d); setPreset("custom"); } }}
                  initialFocus className={cn("p-3 pointer-events-auto")} />
              </PopoverContent>
            </Popover>
          </div>
          <div>
            <Label className="text-xs">Hasta</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className={cn("w-full justify-start text-left font-normal")}>
                  <CalendarIcon className="h-4 w-4 mr-2" />
                  {format(to, "dd MMM yyyy", { locale: es })}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={to} onSelect={(d) => { if (d) { setTo(d); setPreset("custom"); } }}
                  initialFocus className={cn("p-3 pointer-events-auto")} />
              </PopoverContent>
            </Popover>
          </div>
          <div>
            <Label className="text-xs">Agrupar por</Label>
            <Select value={groupBy} onValueChange={(v) => setGroupBy(v as GroupBy)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="company">Empresa</SelectItem>
                <SelectItem value="branch">Empresa + Sede</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="md:col-span-4">
            <Label className="text-xs">Empresas a incluir</Label>
            <div className="flex flex-wrap gap-3 mt-2">
              {companies.map((c) => (
                <label key={c.id} className="flex items-center gap-2 text-sm cursor-pointer">
                  <Checkbox checked={selectedCompanies.includes(c.id)} onCheckedChange={() => toggleCompany(c.id)} />
                  {c.name}
                </label>
              ))}
              {companies.length === 0 && <span className="text-xs text-muted-foreground">No tienes empresas accesibles.</span>}
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="ventas">
        <TabsList>
          <TabsTrigger value="ventas">Ventas</TabsTrigger>
          <TabsTrigger value="productos">Productos</TabsTrigger>
          <TabsTrigger value="inventario">Inventario</TabsTrigger>
          <TabsTrigger value="empleados">Empleados</TabsTrigger>
        </TabsList>

        <TabsContent value="ventas" className="space-y-4">
          <Card><CardContent className="p-4">
            <div className="h-[320px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={ventasData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="label" tick={{ fontSize: 11 }} interval={0} angle={-15} textAnchor="end" height={70} />
                  <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `$${(v / 1_000_000).toFixed(1)}M`} />
                  <Tooltip formatter={(v: number) => fmtCOP(v)} />
                  <Legend />
                  <Bar dataKey="totalVenta" name="Total venta" fill="hsl(var(--primary))" />
                  <Bar dataKey="promedio" name="Promedio diario" fill="hsl(var(--info))" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent></Card>
          <Card><CardContent className="p-0 overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead>Grupo</TableHead>
                <TableHead className="text-right">Total venta</TableHead>
                <TableHead className="text-right">Base inicial</TableHead>
                <TableHead className="text-right">Días</TableHead>
                <TableHead className="text-right">Promedio diario</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {ventasData.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6">Sin datos en el período.</TableCell></TableRow>
                ) : ventasData.map((r) => (
                  <TableRow key={r.key}>
                    <TableCell className="font-medium">{r.label}</TableCell>
                    <TableCell className="text-right tabular-nums">{fmtCOP(r.totalVenta)}</TableCell>
                    <TableCell className="text-right tabular-nums text-muted-foreground">{fmtCOP(r.baseInicial)}</TableCell>
                    <TableCell className="text-right tabular-nums">{r.dias}</TableCell>
                    <TableCell className="text-right tabular-nums">{fmtCOP(r.promedio)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="productos" className="space-y-4">
          <Card><CardContent className="p-4">
            <div className="h-[360px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={productosData} layout="vertical" margin={{ left: 80 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis type="number" tick={{ fontSize: 11 }} tickFormatter={(v) => `$${(v / 1_000_000).toFixed(1)}M`} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={120} />
                  <Tooltip formatter={(v: number) => fmtCOP(v)} />
                  <Bar dataKey="total" name="Total venta" fill="hsl(var(--primary))" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent></Card>
          <Card><CardContent className="p-0 overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead>Producto</TableHead>
                <TableHead className="text-right">Unidades</TableHead>
                <TableHead className="text-right">Total venta</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {productosData.length === 0 ? (
                  <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground py-6">Sin datos en el período.</TableCell></TableRow>
                ) : productosData.map((r) => (
                  <TableRow key={r.name}>
                    <TableCell className="font-medium">{r.name}</TableCell>
                    <TableCell className="text-right tabular-nums">{r.unidades.toLocaleString("es-CO", { maximumFractionDigits: 2 })}</TableCell>
                    <TableCell className="text-right tabular-nums">{fmtCOP(r.total)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="inventario" className="space-y-4">
          <Card><CardContent className="p-4">
            <div className="h-[320px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={inventarioData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="label" tick={{ fontSize: 11 }} interval={0} angle={-15} textAnchor="end" height={70} />
                  <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `$${(v / 1_000_000).toFixed(1)}M`} />
                  <Tooltip formatter={(v: number, n: string) => n === "Valor inventario" ? fmtCOP(v) : v} />
                  <Legend />
                  <Bar dataKey="valor" name="Valor inventario" fill="hsl(var(--primary))" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent></Card>
          <Card><CardContent className="p-0 overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead>Grupo</TableHead>
                <TableHead className="text-right">Productos</TableHead>
                <TableHead className="text-right">Valor inventario</TableHead>
                <TableHead className="text-right">Stock bajo</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {inventarioData.length === 0 ? (
                  <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground py-6">Sin datos.</TableCell></TableRow>
                ) : inventarioData.map((r) => (
                  <TableRow key={r.key}>
                    <TableCell className="font-medium">{r.label}</TableCell>
                    <TableCell className="text-right tabular-nums">{r.productos}</TableCell>
                    <TableCell className="text-right tabular-nums">{fmtCOP(r.valor)}</TableCell>
                    <TableCell className="text-right tabular-nums">
                      {r.bajos > 0 ? <Badge className="bg-warning text-warning-foreground">{r.bajos}</Badge> : <span className="text-muted-foreground">0</span>}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="empleados" className="space-y-4">
          <Card><CardContent className="p-4">
            <div className="h-[320px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={empleadosData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="label" tick={{ fontSize: 11 }} interval={0} angle={-15} textAnchor="end" height={70} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="activos" name="Activos" fill="hsl(var(--primary))" />
                  <Bar dataKey="turnos" name="Turnos en período" fill="hsl(var(--info))" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent></Card>
          <Card><CardContent className="p-0 overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead>Grupo</TableHead>
                <TableHead className="text-right">Activos</TableHead>
                <TableHead className="text-right">Total</TableHead>
                <TableHead className="text-right">Turnos</TableHead>
                <TableHead className="text-right">Horas</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {empleadosData.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6">Sin datos.</TableCell></TableRow>
                ) : empleadosData.map((r) => (
                  <TableRow key={r.key}>
                    <TableCell className="font-medium">{r.label}</TableCell>
                    <TableCell className="text-right tabular-nums">{r.activos}</TableCell>
                    <TableCell className="text-right tabular-nums">{r.total}</TableCell>
                    <TableCell className="text-right tabular-nums">{r.turnos}</TableCell>
                    <TableCell className="text-right tabular-nums">{r.horas}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent></Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
