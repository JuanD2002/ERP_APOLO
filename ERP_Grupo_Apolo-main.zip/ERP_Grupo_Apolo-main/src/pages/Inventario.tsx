import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Package, Plus, ArrowDownToLine, ArrowUpFromLine, AlertTriangle, CalendarDays, Pencil, Download, LineChart as LineChartIcon } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid } from "recharts";
import { toast } from "sonner";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { useCompany } from "@/hooks/useCompany";

interface DailyRow {
  id: string;
  date: string;
  product_name: string;
  inv_inicial: number | null;
  entradas: number | null;
  inv_final: number | null;
  venta_unidades: number | null;
  precio: number | null;
  total_venta: number | null;
}

interface Product {
  id: string;
  name: string;
  category: string;
  unit: string;
  cost: number;
  price: number;
  stock: number;
  min_stock: number;
}

const Inventario = () => {
  const { activeCompanyId, activeBranchId } = useCompany();
  const [products, setProducts] = useState<Product[]>([]);
  const [movements, setMovements] = useState<any[]>([]);
  const [dailyRows, setDailyRows] = useState<DailyRow[]>([]);
  const [availableDates, setAvailableDates] = useState<string[]>([]);
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [openProd, setOpenProd] = useState(false);
  const [openMov, setOpenMov] = useState(false);
  const [movType, setMovType] = useState<"entrada" | "salida">("entrada");
  const [prodForm, setProdForm] = useState({ name: "", category: "", unit: "kg", cost: "", price: "", stock: "0", min_stock: "0" });
  const [movForm, setMovForm] = useState({ product_id: "", quantity: "", unit_price: "", reason: "" });
  const [editProd, setEditProd] = useState<Product | null>(null);
  const [chartProduct, setChartProduct] = useState<string>("");
  const [chartData, setChartData] = useState<DailyRow[]>([]);

  useEffect(() => { void load(); }, [activeCompanyId, activeBranchId]);
  useEffect(() => { void loadDaily(); }, [activeCompanyId, activeBranchId, selectedDate]);

  const load = async () => {
    if (!activeCompanyId) { setProducts([]); setMovements([]); return; }
    let q = supabase.from("products").select("*").eq("company_id", activeCompanyId);
    if (activeBranchId) q = q.eq("branch_id", activeBranchId);
    const { data: prods } = await q.order("name");
    const ids = (prods ?? []).map((p: any) => p.id);
    const { data: movs } = ids.length
      ? await supabase.from("inventory_movements").select("*, products(name, unit)").in("product_id", ids).order("created_at", { ascending: false }).limit(50)
      : { data: [] as any[] };
    setProducts(prods ?? []);
    setMovements(movs ?? []);
  };

  const loadDaily = async () => {
    if (!activeCompanyId) { setDailyRows([]); setAvailableDates([]); return; }
    let dq = supabase.from("daily_product_sales").select("date").eq("company_id", activeCompanyId).order("date", { ascending: false }).limit(500);
    if (activeBranchId) dq = dq.eq("branch_id", activeBranchId);
    const { data: dates } = await dq;
    const uniqDates = Array.from(new Set((dates ?? []).map((d: any) => d.date)));
    setAvailableDates(uniqDates);
    const dateToUse = selectedDate || uniqDates[0] || "";
    if (!selectedDate && uniqDates[0]) setSelectedDate(uniqDates[0]);
    if (!dateToUse) { setDailyRows([]); return; }
    let rq = supabase.from("daily_product_sales").select("*").eq("company_id", activeCompanyId).eq("date", dateToUse).order("product_name");
    if (activeBranchId) rq = rq.eq("branch_id", activeBranchId);
    const { data: rows } = await rq;
    setDailyRows((rows ?? []) as DailyRow[]);
  };

  const loadChart = async (productName: string) => {
    if (!activeCompanyId || !productName) { setChartData([]); return; }
    let q = supabase.from("daily_product_sales").select("*").eq("company_id", activeCompanyId).eq("product_name", productName).order("date", { ascending: true });
    if (activeBranchId) q = q.eq("branch_id", activeBranchId);
    const { data } = await q;
    setChartData((data ?? []) as DailyRow[]);
  };

  const importDailyToStock = async () => {
    if (!activeCompanyId) return toast.error("Selecciona una empresa primero");
    if (dailyRows.length === 0) return toast.error("No hay productos para importar");
    let ok = 0, fail = 0;
    for (const r of dailyRows) {
      let q = supabase.from("products").select("id").eq("company_id", activeCompanyId).eq("name", r.product_name);
      if (activeBranchId) q = q.eq("branch_id", activeBranchId);
      const { data: existing } = await q.maybeSingle();
      const payload = {
        name: r.product_name,
        stock: Number(r.inv_final ?? 0),
        price: Number(r.precio ?? 0),
        company_id: activeCompanyId,
        branch_id: activeBranchId,
      };
      const { error } = existing
        ? await supabase.from("products").update({ stock: payload.stock, price: payload.price }).eq("id", existing.id)
        : await supabase.from("products").insert({ ...payload, category: "Arqueo", unit: "unidad", cost: 0, min_stock: 0 });
      if (error) fail++; else ok++;
    }
    toast.success(`Importados: ${ok}${fail ? ` · errores: ${fail}` : ""}`);
    void load();
  };

  const openEditProduct = (p: Product) => {
    setEditProd(p);
    setProdForm({
      name: p.name, category: p.category, unit: p.unit,
      cost: String(p.cost), price: String(p.price),
      stock: String(p.stock), min_stock: String(p.min_stock),
    });
  };

  const submitEditProduct = async () => {
    if (!editProd) return;
    if (!prodForm.name.trim() || !prodForm.category.trim()) return toast.error("Completa nombre y categoría");
    const { error } = await supabase.from("products").update({
      name: prodForm.name.trim(),
      category: prodForm.category.trim(),
      unit: prodForm.unit,
      cost: Number(prodForm.cost) || 0,
      price: Number(prodForm.price) || 0,
      stock: Number(prodForm.stock) || 0,
      min_stock: Number(prodForm.min_stock) || 0,
    }).eq("id", editProd.id);
    if (error) return toast.error(error.message);
    toast.success("Producto actualizado");
    setEditProd(null);
    setProdForm({ name: "", category: "", unit: "kg", cost: "", price: "", stock: "0", min_stock: "0" });
    void load();
  };

  const fmtCOP = (n: number) =>
    new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 }).format(n);

  const submitProduct = async () => {
    if (!prodForm.name.trim() || !prodForm.category.trim()) {
      toast.error("Completa nombre y categoría");
      return;
    }
    if (!activeCompanyId) return toast.error("Selecciona una empresa primero");
    const { error } = await supabase.from("products").insert({
      name: prodForm.name.trim(),
      category: prodForm.category.trim(),
      unit: prodForm.unit,
      cost: Number(prodForm.cost) || 0,
      price: Number(prodForm.price) || 0,
      stock: Number(prodForm.stock) || 0,
      min_stock: Number(prodForm.min_stock) || 0,
      company_id: activeCompanyId,
      branch_id: activeBranchId,
    });
    if (error) return toast.error(error.message);
    toast.success("Producto creado");
    setOpenProd(false);
    setProdForm({ name: "", category: "", unit: "kg", cost: "", price: "", stock: "0", min_stock: "0" });
    void load();
  };

  const openMovement = (type: "entrada" | "salida") => {
    setMovType(type);
    setMovForm({ product_id: "", quantity: "", unit_price: "", reason: "" });
    setOpenMov(true);
  };

  const submitMovement = async () => {
    if (!movForm.product_id || !movForm.quantity) {
      toast.error("Selecciona producto y cantidad");
      return;
    }
    const qty = Number(movForm.quantity);
    if (qty <= 0) return toast.error("Cantidad inválida");
    const prod = products.find((p) => p.id === movForm.product_id);
    if (movType === "salida" && prod && qty > Number(prod.stock)) {
      return toast.error(`Stock insuficiente (disponible: ${prod.stock} ${prod.unit})`);
    }
    const defaultPrice = prod ? (movType === "entrada" ? prod.cost : prod.price) : 0;
    const { error } = await supabase.from("inventory_movements").insert({
      product_id: movForm.product_id,
      type: movType,
      quantity: qty,
      unit_price: Number(movForm.unit_price) || defaultPrice,
      reason: movForm.reason.trim() || null,
    });
    if (error) return toast.error(error.message);
    toast.success(`${movType === "entrada" ? "Entrada" : "Salida"} registrada`);
    setOpenMov(false);
    void load();
  };

  const lowStock = products.filter((p) => Number(p.stock) <= Number(p.min_stock));
  const totalValue = products.reduce((s, p) => s + Number(p.stock) * Number(p.cost), 0);

  return (
    <div>
      <PageHeader
        title="Inventario"
        description="Productos, stock y movimientos"
        icon={<Package className="h-5 w-5" />}
        action={
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => openMovement("entrada")}><ArrowDownToLine className="h-4 w-4 mr-2" />Entrada</Button>
            <Button variant="outline" onClick={() => openMovement("salida")}><ArrowUpFromLine className="h-4 w-4 mr-2" />Salida</Button>
            <Dialog open={openProd} onOpenChange={setOpenProd}>
              <DialogTrigger asChild>
                <Button><Plus className="h-4 w-4 mr-2" />Producto</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Nuevo producto</DialogTitle></DialogHeader>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="sm:col-span-2"><Label>Nombre *</Label><Input value={prodForm.name} onChange={(e) => setProdForm({ ...prodForm, name: e.target.value })} maxLength={100} /></div>
                  <div><Label>Categoría *</Label><Input value={prodForm.category} onChange={(e) => setProdForm({ ...prodForm, category: e.target.value })} maxLength={50} /></div>
                  <div><Label>Unidad</Label>
                    <Select value={prodForm.unit} onValueChange={(v) => setProdForm({ ...prodForm, unit: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="kg">kg</SelectItem>
                        <SelectItem value="g">g</SelectItem>
                        <SelectItem value="unidad">unidad</SelectItem>
                        <SelectItem value="lt">lt</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div><Label>Costo</Label><Input type="number" value={prodForm.cost} onChange={(e) => setProdForm({ ...prodForm, cost: e.target.value })} /></div>
                  <div><Label>Precio venta</Label><Input type="number" value={prodForm.price} onChange={(e) => setProdForm({ ...prodForm, price: e.target.value })} /></div>
                  <div><Label>Stock inicial</Label><Input type="number" value={prodForm.stock} onChange={(e) => setProdForm({ ...prodForm, stock: e.target.value })} /></div>
                  <div><Label>Stock mínimo</Label><Input type="number" value={prodForm.min_stock} onChange={(e) => setProdForm({ ...prodForm, min_stock: e.target.value })} /></div>
                </div>
                <DialogFooter><Button onClick={submitProduct}>Guardar</Button></DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        }
      />

      {lowStock.length > 0 && (
        <Card className="mb-4 border-warning/40 bg-warning/5">
          <CardContent className="flex items-center gap-3 p-4">
            <AlertTriangle className="h-5 w-5 text-warning shrink-0" />
            <p className="text-sm"><strong>{lowStock.length}</strong> producto(s) por debajo del stock mínimo.</p>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4 text-sm">
        <Card><CardContent className="p-4"><p className="text-muted-foreground text-xs">Productos</p><p className="text-2xl font-bold font-display">{products.length}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-muted-foreground text-xs">Valor inventario</p><p className="text-2xl font-bold font-display">{fmtCOP(totalValue)}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-muted-foreground text-xs">Movimientos hoy</p><p className="text-2xl font-bold font-display">{movements.filter((m) => new Date(m.created_at).toDateString() === new Date().toDateString()).length}</p></CardContent></Card>
      </div>

      <Tabs defaultValue="daily">
        <TabsList>
          <TabsTrigger value="daily">Inventario por fecha</TabsTrigger>
          <TabsTrigger value="stock">Stock actual</TabsTrigger>
          <TabsTrigger value="charts">Gráficas</TabsTrigger>
          <TabsTrigger value="history">Historial movimientos</TabsTrigger>
        </TabsList>

        <TabsContent value="daily">
          <Card>
            <CardContent className="p-4 space-y-4">
              <div className="flex items-center gap-3 flex-wrap">
                <CalendarDays className="h-4 w-4 text-muted-foreground" />
                <Label className="text-sm">Fecha:</Label>
                <Select value={selectedDate} onValueChange={setSelectedDate}>
                  <SelectTrigger className="w-[220px]"><SelectValue placeholder="Selecciona fecha" /></SelectTrigger>
                  <SelectContent>
                    {availableDates.map((d) => (
                      <SelectItem key={d} value={d}>{format(new Date(d + "T00:00:00"), "dd MMM yyyy", { locale: es })}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <span className="text-xs text-muted-foreground flex-1">Datos provenientes de los arqueos diarios</span>
                <Button size="sm" variant="outline" onClick={importDailyToStock} disabled={dailyRows.length === 0}>
                  <Download className="h-4 w-4 mr-2" />Importar a stock
                </Button>
              </div>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader><TableRow>
                    <TableHead>Producto</TableHead>
                    <TableHead className="text-right">Inv. inicial</TableHead>
                    <TableHead className="text-right">Entradas</TableHead>
                    <TableHead className="text-right">Inv. final</TableHead>
                    <TableHead className="text-right">Venta (uds)</TableHead>
                    <TableHead className="text-right">Precio</TableHead>
                    <TableHead className="text-right">Total venta</TableHead>
                  </TableRow></TableHeader>
                  <TableBody>
                    {dailyRows.length === 0 ? (
                      <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-6">Sin datos para esta fecha. Sincroniza un arqueo primero.</TableCell></TableRow>
                    ) : dailyRows.map((r) => (
                      <TableRow key={r.id}>
                        <TableCell className="font-medium">{r.product_name}</TableCell>
                        <TableCell className="text-right tabular-nums">{Number(r.inv_inicial ?? 0).toLocaleString("es-CO", { maximumFractionDigits: 3 })}</TableCell>
                        <TableCell className="text-right tabular-nums">{Number(r.entradas ?? 0).toLocaleString("es-CO", { maximumFractionDigits: 3 })}</TableCell>
                        <TableCell className="text-right tabular-nums">{Number(r.inv_final ?? 0).toLocaleString("es-CO", { maximumFractionDigits: 3 })}</TableCell>
                        <TableCell className="text-right tabular-nums">{Number(r.venta_unidades ?? 0).toLocaleString("es-CO", { maximumFractionDigits: 3 })}</TableCell>
                        <TableCell className="text-right tabular-nums text-muted-foreground">{fmtCOP(Number(r.precio ?? 0))}</TableCell>
                        <TableCell className="text-right tabular-nums">{fmtCOP(Number(r.total_venta ?? 0))}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>


        <TabsContent value="stock">
          <Card><CardContent className="p-0 overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead>Producto</TableHead><TableHead>Categoría</TableHead>
                <TableHead className="text-right">Stock</TableHead><TableHead className="text-right">Mínimo</TableHead>
                <TableHead className="text-right">Costo</TableHead><TableHead className="text-right">Precio</TableHead>
                <TableHead>Estado</TableHead><TableHead className="text-right">Acciones</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {products.map((p) => {
                  const low = Number(p.stock) <= Number(p.min_stock);
                  return (
                    <TableRow key={p.id}>
                      <TableCell className="font-medium">{p.name}</TableCell>
                      <TableCell><Badge variant="secondary">{p.category}</Badge></TableCell>
                      <TableCell className="text-right tabular-nums">{Number(p.stock).toFixed(2)} {p.unit}</TableCell>
                      <TableCell className="text-right tabular-nums text-muted-foreground">{Number(p.min_stock).toFixed(0)}</TableCell>
                      <TableCell className="text-right tabular-nums text-muted-foreground">{fmtCOP(Number(p.cost))}</TableCell>
                      <TableCell className="text-right tabular-nums">{fmtCOP(Number(p.price))}</TableCell>
                      <TableCell>{low ? <Badge className="bg-warning text-warning-foreground">Bajo</Badge> : <Badge className="bg-success text-success-foreground">OK</Badge>}</TableCell>
                      <TableCell className="text-right">
                        <Button size="sm" variant="ghost" onClick={() => openEditProduct(p)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="charts">
          <Card>
            <CardContent className="p-4 space-y-4">
              <div className="flex items-center gap-3 flex-wrap">
                <LineChartIcon className="h-4 w-4 text-muted-foreground" />
                <Label className="text-sm">Producto:</Label>
                <Select
                  value={chartProduct}
                  onValueChange={(v) => { setChartProduct(v); void loadChart(v); }}
                >
                  <SelectTrigger className="w-[260px]"><SelectValue placeholder="Selecciona un producto" /></SelectTrigger>
                  <SelectContent>
                    {Array.from(new Set(dailyRows.map((r) => r.product_name))).map((n) => (
                      <SelectItem key={n} value={n}>{n}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <span className="text-xs text-muted-foreground">Comportamiento histórico (inv. inicial, final y venta)</span>
              </div>
              {chartData.length === 0 ? (
                <p className="text-center text-muted-foreground py-12 text-sm">Selecciona un producto para ver su histórico.</p>
              ) : (
                <div className="h-[360px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData.map((d) => ({
                      date: format(new Date(d.date + "T00:00:00"), "dd MMM", { locale: es }),
                      "Inv. inicial": Number(d.inv_inicial ?? 0),
                      "Inv. final": Number(d.inv_final ?? 0),
                      "Venta (uds)": Number(d.venta_unidades ?? 0),
                    }))}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="Inv. inicial" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
                      <Line type="monotone" dataKey="Inv. final" stroke="hsl(var(--info))" strokeWidth={2} dot={false} />
                      <Line type="monotone" dataKey="Venta (uds)" stroke="hsl(var(--success))" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card><CardContent className="p-0 overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead>Fecha</TableHead><TableHead>Producto</TableHead>
                <TableHead>Tipo</TableHead><TableHead className="text-right">Cantidad</TableHead>
                <TableHead className="text-right">Precio unit.</TableHead><TableHead>Motivo</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {movements.map((m) => (
                  <TableRow key={m.id}>
                    <TableCell className="text-sm">{format(new Date(m.created_at), "dd MMM HH:mm", { locale: es })}</TableCell>
                    <TableCell>{m.products?.name}</TableCell>
                    <TableCell>
                      {m.type === "entrada"
                        ? <Badge className="bg-success text-success-foreground"><ArrowDownToLine className="h-3 w-3 mr-1" />Entrada</Badge>
                        : <Badge className="bg-info text-info-foreground"><ArrowUpFromLine className="h-3 w-3 mr-1" />Salida</Badge>}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">{Number(m.quantity).toFixed(2)} {m.products?.unit}</TableCell>
                    <TableCell className="text-right tabular-nums">{fmtCOP(Number(m.unit_price))}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{m.reason ?? "—"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent></Card>
        </TabsContent>
      </Tabs>

      {/* Movement dialog */}
      <Dialog open={openMov} onOpenChange={setOpenMov}>
        <DialogContent>
          <DialogHeader><DialogTitle>Registrar {movType === "entrada" ? "entrada (compra)" : "salida (venta)"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Producto</Label>
              <Select value={movForm.product_id} onValueChange={(v) => setMovForm({ ...movForm, product_id: v })}>
                <SelectTrigger><SelectValue placeholder="Selecciona un producto" /></SelectTrigger>
                <SelectContent>
                  {products.map((p) => <SelectItem key={p.id} value={p.id}>{p.name} — stock: {Number(p.stock).toFixed(2)} {p.unit}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Cantidad</Label><Input type="number" step="0.01" value={movForm.quantity} onChange={(e) => setMovForm({ ...movForm, quantity: e.target.value })} /></div>
              <div><Label>Precio unitario</Label><Input type="number" value={movForm.unit_price} onChange={(e) => setMovForm({ ...movForm, unit_price: e.target.value })} placeholder="auto" /></div>
            </div>
            <div><Label>Motivo</Label><Input value={movForm.reason} onChange={(e) => setMovForm({ ...movForm, reason: e.target.value })} maxLength={120} placeholder={movType === "entrada" ? "Compra proveedor" : "Venta mostrador"} /></div>
          </div>
          <DialogFooter><Button onClick={submitMovement}>Registrar</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit product dialog */}
      <Dialog open={!!editProd} onOpenChange={(o) => !o && setEditProd(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Editar producto</DialogTitle></DialogHeader>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2"><Label>Nombre *</Label><Input value={prodForm.name} onChange={(e) => setProdForm({ ...prodForm, name: e.target.value })} maxLength={100} /></div>
            <div><Label>Categoría *</Label><Input value={prodForm.category} onChange={(e) => setProdForm({ ...prodForm, category: e.target.value })} maxLength={50} /></div>
            <div><Label>Unidad</Label>
              <Select value={prodForm.unit} onValueChange={(v) => setProdForm({ ...prodForm, unit: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="kg">kg</SelectItem>
                  <SelectItem value="g">g</SelectItem>
                  <SelectItem value="unidad">unidad</SelectItem>
                  <SelectItem value="lt">lt</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Costo</Label><Input type="number" value={prodForm.cost} onChange={(e) => setProdForm({ ...prodForm, cost: e.target.value })} /></div>
            <div><Label>Precio venta</Label><Input type="number" value={prodForm.price} onChange={(e) => setProdForm({ ...prodForm, price: e.target.value })} /></div>
            <div><Label>Stock</Label><Input type="number" step="0.01" value={prodForm.stock} onChange={(e) => setProdForm({ ...prodForm, stock: e.target.value })} /></div>
            <div><Label>Stock mínimo</Label><Input type="number" value={prodForm.min_stock} onChange={(e) => setProdForm({ ...prodForm, min_stock: e.target.value })} /></div>
          </div>
          <DialogFooter><Button onClick={submitEditProduct}>Guardar cambios</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Inventario;
