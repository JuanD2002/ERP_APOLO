import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building2, Save, FileSpreadsheet, ExternalLink, AlertCircle, RefreshCw, MapPin, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useCompany } from "@/hooks/useCompany";

interface Branch { id: string; name: string; company_id: string; }
interface GIntegration {
  id?: string;
  company_id: string;
  branch_id: string | null;
  google_email: string | null;
  spreadsheet_id: string | null;
  sheet_name_pattern: string;
  failover_enabled: boolean;
  sync_enabled: boolean;
  last_synced_at: string | null;
}

const empty = (company_id: string, branch_id: string | null = null): GIntegration => ({
  company_id, branch_id,
  google_email: null,
  spreadsheet_id: null,
  sheet_name_pattern: "{day}",
  failover_enabled: false,
  sync_enabled: false,
  last_synced_at: null,
});

const MONTHS = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];

export default function GoogleIntegrationsTab() {
  const { companies } = useCompany();
  const [branches, setBranches] = useState<Branch[]>([]);
  const [rows, setRows] = useState<GIntegration[]>([]);
  const [saving, setSaving] = useState<string | null>(null);
  const [syncing, setSyncing] = useState<string | null>(null);
  const [month, setMonth] = useState<number>(new Date().getMonth() + 1);
  const [year, setYear] = useState<number>(new Date().getFullYear());

  useEffect(() => { void load(); }, [companies.length]);

  const load = async () => {
    const [{ data: br }, { data: integ }] = await Promise.all([
      supabase.from("branches").select("id,name,company_id").eq("is_active", true).order("name"),
      supabase.from("company_google_integrations" as any).select("*"),
    ]);
    setBranches((br as any) ?? []);
    setRows(((integ as any) ?? []) as GIntegration[]);
  };

  const rowFor = (companyId: string, branchId: string | null) =>
    rows.find((r) => r.company_id === companyId && (r.branch_id ?? null) === branchId) ?? empty(companyId, branchId);

  const update = (companyId: string, branchId: string | null, patch: Partial<GIntegration>) => {
    setRows((prev) => {
      const idx = prev.findIndex((r) => r.company_id === companyId && (r.branch_id ?? null) === branchId);
      if (idx === -1) return [...prev, { ...empty(companyId, branchId), ...patch }];
      const next = [...prev];
      next[idx] = { ...next[idx], ...patch };
      return next;
    });
  };

  const save = async (companyId: string, branchId: string | null) => {
    const key = `${companyId}:${branchId ?? "all"}`;
    setSaving(key);
    const row = rowFor(companyId, branchId);
    const payload = { ...row, company_id: companyId, branch_id: branchId };
    delete (payload as any).id;
    // Manual upsert by (company_id, branch_id) — Supabase needs explicit unique
    const existing = rows.find((r) => r.company_id === companyId && (r.branch_id ?? null) === branchId && r.id);
    const { error } = existing
      ? await supabase.from("company_google_integrations" as any).update(payload).eq("id", existing.id!)
      : await supabase.from("company_google_integrations" as any).insert(payload);
    setSaving(null);
    if (error) return toast.error(error.message);
    toast.success("Configuración guardada");
    void load();
  };

  const remove = async (id: string) => {
    if (!confirm("¿Eliminar esta configuración?")) return;
    const { error } = await supabase.from("company_google_integrations" as any).delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Eliminada");
    void load();
  };

  const sync = async (companyId: string, branchId: string | null) => {
    const key = `${companyId}:${branchId ?? "all"}`;
    setSyncing(key);
    const { data, error } = await supabase.functions.invoke("sync-sheets-daily", {
      body: { company_id: companyId, branch_id: branchId, month, year },
    });
    setSyncing(null);
    if (error) return toast.error(error.message);
    const r = (data ?? {}) as { days_synced?: number; products_synced?: number; errors?: any[]; error?: string };
    if (r.error) return toast.error(r.error);
    toast.success(`Sincronizados ${r.days_synced ?? 0} días, ${r.products_synced ?? 0} productos${r.errors?.length ? ` (${r.errors.length} errores)` : ""}`);
    void load();
  };

  const addBranchMapping = (companyId: string, branchId: string) => {
    if (rows.some((r) => r.company_id === companyId && r.branch_id === branchId)) {
      return toast.info("Esta sede ya tiene mapeo");
    }
    setRows((prev) => [...prev, empty(companyId, branchId)]);
  };

  return (
    <div className="space-y-4">
      <Card className="border-info/30 bg-info/5">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <AlertCircle className="h-4 w-4 text-info" /> Cómo configurarlo
          </CardTitle>
        </CardHeader>
        <CardContent className="text-foreground -mt-2">
          <ol className="list-decimal list-inside space-y-1 text-sm">
            <li>En Lovable conecta el connector <strong>Google Sheets</strong> (workspace settings → Connectors).</li>
            <li>Para cada <strong>sede</strong>, crea un libro con una hoja por día (nombres: <code>1, 2, 3 ... 31</code>) usando el formato del Arqueo de Caja.</li>
            <li>Comparte el libro con la cuenta Google del connector (permiso lectura).</li>
            <li>Pega el <strong>Spreadsheet ID</strong> y selecciona la sede. Patrón: <code>{`{day}`}</code> = número del día.</li>
            <li>Selecciona mes/año y pulsa <strong>Sincronizar</strong> para importar el cierre de caja y ventas por producto.</li>
            <li>Productos fijos: PIZZA, GAS 2.5, VASOS, GAS 1.5, H2O, HIT 8 ONZ, AGUA, MR TEE, HIT 500, 400 ML, ADICIONES, CAJAS 40x40, CAJAS PORCIÓN, INDIVIDUALES PEQ/GDE, PIZZERITOS COMBO.</li>
          </ol>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <RefreshCw className="h-4 w-4" /> Periodo a sincronizar
          </CardTitle>
        </CardHeader>
        <CardContent className="flex gap-3">
          <div className="w-40">
            <Label className="text-xs">Mes</Label>
            <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {MONTHS.map((m, i) => <SelectItem key={i+1} value={String(i+1)}>{m}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="w-32">
            <Label className="text-xs">Año</Label>
            <Input type="number" value={year} onChange={(e) => setYear(Number(e.target.value))} />
          </div>
        </CardContent>
      </Card>

      {companies.map((c) => {
        const companyBranches = branches.filter((b) => b.company_id === c.id);
        const companyRows = rows.filter((r) => r.company_id === c.id);
        // Always include a "company-level" slot
        const slots: { branchId: string | null; branchName: string }[] = [
          { branchId: null, branchName: "Empresa (sin sede específica)" },
          ...companyRows
            .filter((r) => r.branch_id)
            .map((r) => ({ branchId: r.branch_id, branchName: companyBranches.find((b) => b.id === r.branch_id)?.name ?? "Sede eliminada" })),
        ];
        const availableToAdd = companyBranches.filter((b) => !companyRows.some((r) => r.branch_id === b.id));

        return (
          <Card key={c.id}>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Building2 className="h-4 w-4" /> {c.name}
              </CardTitle>
              {availableToAdd.length > 0 && (
                <div className="flex items-center gap-2 pt-2">
                  <Label className="text-xs">Añadir mapeo de sede:</Label>
                  <Select onValueChange={(v) => addBranchMapping(c.id, v)}>
                    <SelectTrigger className="w-64"><SelectValue placeholder="Selecciona sede…" /></SelectTrigger>
                    <SelectContent>
                      {availableToAdd.map((b) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </CardHeader>
            <CardContent className="space-y-4">
              {slots.map((slot) => {
                const g = rowFor(c.id, slot.branchId);
                const sheetUrl = g.spreadsheet_id ? `https://docs.google.com/spreadsheets/d/${g.spreadsheet_id}/edit` : null;
                const key = `${c.id}:${slot.branchId ?? "all"}`;
                return (
                  <div key={key} className="border rounded-lg p-3 space-y-3 bg-muted/20">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium text-sm">{slot.branchName}</span>
                        {g.failover_enabled && <Badge variant="outline" className="border-success text-success">failover</Badge>}
                        {g.sync_enabled && <Badge variant="outline" className="border-info text-info">sync</Badge>}
                      </div>
                      {g.id && slot.branchId && (
                        <Button variant="ghost" size="icon" onClick={() => remove(g.id!)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      )}
                    </div>

                    <div className="grid sm:grid-cols-3 gap-3">
                      <div className="sm:col-span-2">
                        <Label className="text-xs">Spreadsheet ID</Label>
                        <Input
                          value={g.spreadsheet_id ?? ""}
                          onChange={(e) => update(c.id, slot.branchId, { spreadsheet_id: e.target.value || null })}
                          placeholder="1BxiMVs0XRA5..."
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Patrón de hoja</Label>
                        <Input
                          value={g.sheet_name_pattern}
                          onChange={(e) => update(c.id, slot.branchId, { sheet_name_pattern: e.target.value })}
                          placeholder="{day}"
                        />
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-6">
                      <label className="flex items-center gap-2 text-sm">
                        <Switch checked={g.failover_enabled} onCheckedChange={(v) => update(c.id, slot.branchId, { failover_enabled: v })} />
                        Failover
                      </label>
                      <label className="flex items-center gap-2 text-sm">
                        <Switch checked={g.sync_enabled} onCheckedChange={(v) => update(c.id, slot.branchId, { sync_enabled: v })} />
                        Auto-sync
                      </label>
                      <div className="ml-auto flex gap-2 flex-wrap">
                        {sheetUrl && (
                          <Button variant="outline" size="sm" asChild>
                            <a href={sheetUrl} target="_blank" rel="noreferrer"><FileSpreadsheet className="h-4 w-4 mr-2" />Abrir <ExternalLink className="h-3 w-3 ml-1" /></a>
                          </Button>
                        )}
                        <Button size="sm" variant="secondary" onClick={() => sync(c.id, slot.branchId)} disabled={!g.spreadsheet_id || syncing === key}>
                          <RefreshCw className={`h-4 w-4 mr-2 ${syncing === key ? "animate-spin" : ""}`} />
                          {syncing === key ? "Sincronizando…" : "Sincronizar mes"}
                        </Button>
                        <Button size="sm" onClick={() => save(c.id, slot.branchId)} disabled={saving === key}>
                          <Save className="h-4 w-4 mr-2" />{saving === key ? "Guardando…" : "Guardar"}
                        </Button>
                      </div>
                    </div>
                    {g.last_synced_at && (
                      <p className="text-xs text-muted-foreground">Última sincronización: {new Date(g.last_synced_at).toLocaleString("es-CO")}</p>
                    )}
                  </div>
                );
              })}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
