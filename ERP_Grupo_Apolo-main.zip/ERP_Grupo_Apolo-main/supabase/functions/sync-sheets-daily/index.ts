// Sincroniza datos diarios desde Google Sheets (un libro por sede)
// Estructura esperada: cada hoja es un día (nombre = número de día), con el formato del Arqueo de Caja.
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { createClient } from "npm:@supabase/supabase-js@2";

const MONTHS_ES: Record<string, number> = {
  ENERO: 1, FEBRERO: 2, MARZO: 3, ABRIL: 4, MAYO: 5, JUNIO: 6,
  JULIO: 7, AGOSTO: 8, SEPTIEMBRE: 9, OCTUBRE: 10, NOVIEMBRE: 11, DICIEMBRE: 12,
};

const GATEWAY = "https://connector-gateway.lovable.dev/google_sheets/v4";

// Etiquetas que NO son productos aunque aparezcan dentro del bloque
const NON_PRODUCT_LABELS = new Set([
  "PRODUCTO", "BASE INICIAL", "TOTAL VENTA", "BASE INICIAL + TOTAL VENTA",
  "INVENTARIO DE EMPAQUES", "INVENTARIO EMPAQUES",
]);

function norm(s: unknown): string {
  return String(s ?? "").trim().toUpperCase().replace(/\s+/g, " ");
}

// Números en formato colombiano: "." miles, "," decimal. También limpia "$" y espacios.
// Ej.: " $1.386.000" -> 1386000;  "236,125" -> 236.125;  "19,250" -> 19.25
function num(v: unknown): number {
  if (v === null || v === undefined) return 0;
  let s = String(v).trim();
  if (!s) return 0;
  s = s.replace(/\$/g, "").replace(/\s/g, "");
  if (s === "" || s === "-") return 0;
  const hasComma = s.includes(",");
  const hasDot = s.includes(".");
  if (hasComma && hasDot) {
    // formato es-CO: puntos = miles, coma = decimal
    s = s.replace(/\./g, "").replace(",", ".");
  } else if (hasComma) {
    // solo coma -> decimal
    s = s.replace(",", ".");
  } else if (hasDot) {
    // solo punto: si son grupos de 3 dígitos asumimos miles
    if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, "");
  }
  const n = Number(s);
  return Number.isFinite(n) ? n : 0;
}

async function fetchSheet(spreadsheetId: string, sheetName: string) {
  const lovableKey = Deno.env.get("LOVABLE_API_KEY");
  const connKey = Deno.env.get("GOOGLE_SHEETS_API_KEY");
  if (!lovableKey || !connKey) {
    throw new Error("Faltan credenciales del conector Google Sheets. Conecta google_sheets en Lovable.");
  }
  // Solo columnas B–I (más A vacío para mantener índices) — lo demás del libro son notas auxiliares.
  const range = `'${sheetName}'!A1:I60`;
  const url = `${GATEWAY}/spreadsheets/${spreadsheetId}/values/${range}`;
  const r = await fetch(url, {
    headers: {
      Authorization: `Bearer ${lovableKey}`,
      "X-Connection-Api-Key": connKey,
    },
  });
  if (!r.ok) {
    const t = await r.text();
    throw new Error(`Sheets ${sheetName}: HTTP ${r.status} ${t.slice(0, 200)}`);
  }
  const j = await r.json();
  return (j.values ?? []) as unknown[][];
}

function parseDay(values: unknown[][], fallbackMonth: number, fallbackYear: number) {
  // Find FECHA row
  let day = 0, month = fallbackMonth, year = fallbackYear;
  for (const row of values.slice(0, 8)) {
    for (let c = 0; c < row.length; c++) {
      if (norm(row[c]) === "FECHA") {
        day = num(row[c + 1]);
        const m = norm(row[c + 2]);
        if (MONTHS_ES[m]) month = MONTHS_ES[m];
        const y = num(row[c + 3]);
        if (y > 1900) year = y;
        return { day, month, year };
      }
    }
  }
  return { day, month, year };
}

function findRow(values: unknown[][], label: string): unknown[] | null {
  const target = norm(label);
  for (const row of values) {
    for (const cell of row) {
      if (norm(cell) === target) return row;
    }
  }
  return null;
}

// Recorre las filas de productos. La hoja tiene dos bloques:
//   1. Productos de venta entre la fila "PRODUCTO" (encabezado) y "TOTAL VENTA".
//   2. "INVENTARIO DE EMPAQUES" hasta el fin (sin precio/total venta).
// Cada fila válida ocupa columnas B..H:  B nombre, C inv.inicial, D entradas, E inv.final, F venta, G precio, H total venta.
function extractProducts(values: unknown[][]) {
  const items: {
    product_name: string;
    inv_inicial: number;
    entradas: number;
    inv_final: number;
    venta_unidades: number;
    precio: number;
    total_venta: number;
  }[] = [];

  let headerRow = -1;
  let totalVentaRow = -1;
  let empaquesRow = -1;
  for (let r = 0; r < values.length; r++) {
    const label = norm(values[r]?.[1]);
    if (label === "PRODUCTO" && headerRow === -1) headerRow = r;
    if (label === "TOTAL VENTA" && totalVentaRow === -1) totalVentaRow = r;
    if ((label === "INVENTARIO DE EMPAQUES" || label === "INVENTARIO EMPAQUES") && empaquesRow === -1) empaquesRow = r;
  }
  if (headerRow === -1) return items;

  const pushRange = (from: number, to: number) => {
    for (let r = from; r < to && r < values.length; r++) {
      const row = values[r] ?? [];
      const name = String(row[1] ?? "").trim();
      const key = norm(name);
      if (!name || NON_PRODUCT_LABELS.has(key)) continue;
      items.push({
        product_name: name,
        inv_inicial: num(row[2]),
        entradas: num(row[3]),
        inv_final: num(row[4]),
        venta_unidades: num(row[5]),
        precio: num(row[6]),
        total_venta: num(row[7]),
      });
    }
  };

  const ventasEnd = totalVentaRow > 0 ? totalVentaRow : (empaquesRow > 0 ? empaquesRow : values.length);
  pushRange(headerRow + 1, ventasEnd);
  if (empaquesRow > 0) pushRange(empaquesRow + 1, values.length);

  return items;
}

function extractTotals(values: unknown[][]) {
  // Valor en columna I (índice 8) en la fila cuya celda B coincide con la etiqueta.
  const valueAtI = (label: string): number => {
    const target = norm(label);
    for (const row of values) {
      if (norm(row?.[1]) === target) return num(row[8]);
    }
    return 0;
  };
  return {
    base_inicial: valueAtI("BASE INICIAL"),
    total_venta_sheet: valueAtI("TOTAL VENTA"),
    total_efectivo: 0, // ya no se lee del libro (estaba fuera de B–I)
    cash_breakdown: [] as { denomination: number; quantity: number; subtotal: number }[],
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const SB_URL = Deno.env.get("SUPABASE_URL")!;
    const SB_ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
    const SB_SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const authHeader = req.headers.get("Authorization") ?? "";
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "No autenticado" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userClient = createClient(SB_URL, SB_ANON, { global: { headers: { Authorization: authHeader } } });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "No autenticado" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json().catch(() => ({}));
    const { company_id, branch_id, month, year } = body as {
      company_id: string; branch_id?: string | null; month: number; year: number;
    };
    if (!company_id || !month || !year) {
      return new Response(JSON.stringify({ error: "company_id, month y year requeridos" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verify access via user RLS
    const admin = createClient(SB_URL, SB_SERVICE);
    const { data: perm } = await userClient
      .from("companies").select("id").eq("id", company_id).maybeSingle();
    if (!perm) {
      return new Response(JSON.stringify({ error: "Sin acceso a la empresa" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Find integration: branch-specific first, then company-level
    const baseQ = admin.from("company_google_integrations").select("*").eq("company_id", company_id);
    let { data: integ } = branch_id
      ? await baseQ.eq("branch_id", branch_id).maybeSingle()
      : await baseQ.is("branch_id", null).maybeSingle();
    if (!integ && branch_id) {
      const fallback = await admin
        .from("company_google_integrations")
        .select("*").eq("company_id", company_id).is("branch_id", null).maybeSingle();
      integ = fallback.data;
    }
    if (!integ?.spreadsheet_id) {
      return new Response(JSON.stringify({ error: "No hay spreadsheet configurado para esta empresa/sede" }), {
        status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const daysInMonth = new Date(year, month, 0).getDate();
    const cashRows: Record<string, unknown>[] = [];
    const productRows: Record<string, unknown>[] = [];
    const errors: { day: number; error: string }[] = [];

    for (let d = 1; d <= daysInMonth; d++) {
      const sheetName = (integ.sheet_name_pattern ?? "{day}").replace("{day}", String(d));
      try {
        const values = await fetchSheet(integ.spreadsheet_id, sheetName);
        if (!values.length) continue;
        const { day, month: m, year: y } = parseDay(values, month, year);
        const dayNum = day || d;
        const dateStr = `${y}-${String(m).padStart(2, "0")}-${String(dayNum).padStart(2, "0")}`;

        const totals = extractTotals(values);
        const products = extractProducts(values);
        let totalVentaSum = 0;
        for (const p of products) {
          totalVentaSum += p.total_venta;
          productRows.push({
            company_id, branch_id: branch_id ?? null, date: dateStr,
            ...p, source: "sheets",
          });
        }

        cashRows.push({
          company_id, branch_id: branch_id ?? null, date: dateStr,
          base_inicial: totals.base_inicial,
          total_efectivo: totals.total_efectivo,
          total_venta: totals.total_venta_sheet || totalVentaSum,
          cash_breakdown: totals.cash_breakdown,
          source: "sheets",
        });
      } catch (e) {
        errors.push({ day: d, error: (e as Error).message });
      }
    }

    // Borrar y reinsertar para evitar duplicados (branch_id NULL rompe el upsert por unique constraint).
    const dates = Array.from(new Set([...cashRows, ...productRows].map((r: any) => r.date)));
    if (dates.length) {
      const delCash = admin.from("daily_cash_close").delete()
        .eq("company_id", company_id).in("date", dates);
      const delProd = admin.from("daily_product_sales").delete()
        .eq("company_id", company_id).in("date", dates);
      const [dc, dp] = await Promise.all([
        branch_id ? delCash.eq("branch_id", branch_id) : delCash.is("branch_id", null),
        branch_id ? delProd.eq("branch_id", branch_id) : delProd.is("branch_id", null),
      ]);
      if (dc.error) throw dc.error;
      if (dp.error) throw dp.error;
    }

    if (cashRows.length) {
      const { error } = await admin.from("daily_cash_close").insert(cashRows);
      if (error) throw error;
    }
    if (productRows.length) {
      const { error } = await admin.from("daily_product_sales").insert(productRows);
      if (error) throw error;
    }

    await admin.from("company_google_integrations")
      .update({ last_synced_at: new Date().toISOString() }).eq("id", integ.id);

    return new Response(JSON.stringify({
      ok: true,
      days_synced: cashRows.length,
      products_synced: productRows.length,
      errors,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
