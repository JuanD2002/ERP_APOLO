
CREATE TABLE public.manual_links (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  manual_id UUID NOT NULL REFERENCES public.manuals(id) ON DELETE CASCADE,
  linked_manual_id UUID NOT NULL REFERENCES public.manuals(id) ON DELETE CASCADE,
  label TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (manual_id, linked_manual_id),
  CHECK (manual_id <> linked_manual_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.manual_links TO authenticated;
GRANT ALL ON public.manual_links TO service_role;

ALTER TABLE public.manual_links ENABLE ROW LEVEL SECURITY;

CREATE POLICY "View manual links by company access"
ON public.manual_links FOR SELECT TO authenticated
USING (public.has_company_module(auth.uid(), company_id, 'manuales'::app_module, false));

CREATE POLICY "Manage manual links with edit access"
ON public.manual_links FOR ALL TO authenticated
USING (public.has_company_module(auth.uid(), company_id, 'manuales'::app_module, true))
WITH CHECK (public.has_company_module(auth.uid(), company_id, 'manuales'::app_module, true));

CREATE INDEX idx_manual_links_manual_id ON public.manual_links(manual_id);
CREATE INDEX idx_manual_links_linked_manual_id ON public.manual_links(linked_manual_id);
