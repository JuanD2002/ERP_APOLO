ALTER TABLE public.company_google_integrations DROP CONSTRAINT IF EXISTS company_google_integrations_company_id_key;
CREATE UNIQUE INDEX IF NOT EXISTS company_google_integrations_company_branch_uniq
  ON public.company_google_integrations (company_id, COALESCE(branch_id, '00000000-0000-0000-0000-000000000000'::uuid));