
-- 1. Allow per-branch Google Sheets mapping
ALTER TABLE public.company_google_integrations
  ADD COLUMN IF NOT EXISTS branch_id uuid REFERENCES public.branches(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS sheet_name_pattern text DEFAULT '{day}';

CREATE INDEX IF NOT EXISTS idx_cgi_company_branch ON public.company_google_integrations(company_id, branch_id);

-- 2. Daily cash close (one row per company/branch/date)
CREATE TABLE IF NOT EXISTS public.daily_cash_close (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  branch_id uuid REFERENCES public.branches(id) ON DELETE SET NULL,
  date date NOT NULL,
  base_inicial numeric DEFAULT 0,
  total_efectivo numeric DEFAULT 0,
  total_venta numeric DEFAULT 0,
  cuadre numeric GENERATED ALWAYS AS (COALESCE(total_efectivo,0) - COALESCE(base_inicial,0) - COALESCE(total_venta,0)) STORED,
  cash_breakdown jsonb DEFAULT '[]'::jsonb,
  source text DEFAULT 'sheets',
  raw jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, branch_id, date)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.daily_cash_close TO authenticated;
GRANT ALL ON public.daily_cash_close TO service_role;
ALTER TABLE public.daily_cash_close ENABLE ROW LEVEL SECURITY;

CREATE POLICY "View cash close in own companies"
  ON public.daily_cash_close FOR SELECT TO authenticated
  USING (company_id IN (SELECT public.user_company_ids(auth.uid())));

CREATE POLICY "Manage cash close with module"
  ON public.daily_cash_close FOR ALL TO authenticated
  USING (public.has_company_module(auth.uid(), company_id, 'inventario'::app_module, true))
  WITH CHECK (public.has_company_module(auth.uid(), company_id, 'inventario'::app_module, true));

CREATE TRIGGER trg_daily_cash_close_updated
  BEFORE UPDATE ON public.daily_cash_close
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 3. Daily product sales (one row per company/branch/date/product)
CREATE TABLE IF NOT EXISTS public.daily_product_sales (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  branch_id uuid REFERENCES public.branches(id) ON DELETE SET NULL,
  date date NOT NULL,
  product_name text NOT NULL,
  inv_inicial numeric DEFAULT 0,
  entradas numeric DEFAULT 0,
  inv_final numeric DEFAULT 0,
  venta_unidades numeric DEFAULT 0,
  precio numeric DEFAULT 0,
  total_venta numeric DEFAULT 0,
  source text DEFAULT 'sheets',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, branch_id, date, product_name)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.daily_product_sales TO authenticated;
GRANT ALL ON public.daily_product_sales TO service_role;
ALTER TABLE public.daily_product_sales ENABLE ROW LEVEL SECURITY;

CREATE POLICY "View product sales in own companies"
  ON public.daily_product_sales FOR SELECT TO authenticated
  USING (company_id IN (SELECT public.user_company_ids(auth.uid())));

CREATE POLICY "Manage product sales with module"
  ON public.daily_product_sales FOR ALL TO authenticated
  USING (public.has_company_module(auth.uid(), company_id, 'inventario'::app_module, true))
  WITH CHECK (public.has_company_module(auth.uid(), company_id, 'inventario'::app_module, true));

CREATE INDEX IF NOT EXISTS idx_dps_company_date ON public.daily_product_sales(company_id, date);
CREATE INDEX IF NOT EXISTS idx_dps_branch_date ON public.daily_product_sales(branch_id, date);

CREATE TRIGGER trg_daily_product_sales_updated
  BEFORE UPDATE ON public.daily_product_sales
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
